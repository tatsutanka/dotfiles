### [Alacritty](https://github.com/alacritty/alacritty)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/alacritty/archive/master.zip) option.

You just have to import `dracula.yml` in `~/.config/alacritty/alacritty.yml`.

``` yaml
import:
  - /path/to/dracula.yml
```
